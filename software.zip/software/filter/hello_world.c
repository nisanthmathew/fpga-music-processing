/*
 * Authors: Nisanth Mathew James, Twaha Kabika
 * equalizer for left and right channel,
 * lrselect low for cpu0(left channel cpu) and lrselect high for cpu1(right channel cpu)
 * The work presented as the final exam for the Hardware/Software CoDesign course
 * Date : 19.02.2018
 */
#include <math.h>
#include <stdio.h>
#include <system.h>
#include <altera_avalon_pio_regs.h>
#include <alt_types.h>
alt_16 audioleftin = 0x0000;
alt_u16 filterselect = 0b000000;
alt_u16 loopback = 0b0;
alt_u16 lrselect;
int audioleftout2=0;
int audioleftoutlow[14]; //buffer for low pass filter
int audioleftoutpop[21];//buffer for pop
int audioleftouthigh[13]; //buffer for high pass filter
int audioleftoutflat[14]; //buffer for flat
int audioleftoutrock[31]; //buffer for flat
alt_16 audioout_binary = 0x0000;
int j=0;
alt_u16 debug = 0b00;
// high pass coefficients
int impulsehigh[13] = {  -1 ,   -2 ,   -4 ,   -8 ,  -12,   -15 ,  241 ,  -15 ,  -12 ,   -8  ,  -4 ,   -2  ,  -1};
// low pass coefficients
int impulselow[14]  = {   3  ,  5  , 10 ,  17 ,  25 ,  32 ,  36  , 36 ,  32 ,  25   ,17 ,  10  ,  5 ,   3};
// band pass coefficients
int impulsepop[21] = {   -2  , -4 ,  -8 , -12,  -14 , -11 ,  -1,   14,   30,   43,   47 ,  43 ,  30,   14,   -1 , -11 , -14 , -12,   -8 ,  -4  , -2};
// flat coefficients
int impulseflat[14] = { 0  ,  1 ,  -4 , -16 ,  -8 ,  41 ,  97 ,  97  , 41 ,  -8 , -16 ,  -4  ,  1 ,   0};
int impulserock[31] = {   1 ,    2 ,    2 ,    3   ,  3 ,    4  ,   3 ,    2 ,   0 ,   -4 ,   -8  , -13 ,  -17,   -21,   -23 ,  388,
		-23 ,  -21 ,  -17,   -13,	 -8  ,  -4  ,  0 ,    2 ,    3,     4  ,   3  ,   3   ,  2,     2 ,    1};
int main()
{

while (1)
{
//equalizer selection
filterselect = IORD_ALTERA_AVALON_PIO_DATA(PIO_0_BASE);
loopback = IORD_ALTERA_AVALON_PIO_DATA(PIO_3_BASE);

//low pas filter sw2------------------------------------------------------------------------------------------------------------------------
if(filterselect & 0b000001)
{
	audioleftin = IORD_ALTERA_AVALON_PIO_DATA(PIO_IN_BASE);
	audioleftoutlow[j] = (int)audioleftin;
	// filter implementation
	for (int i = 0 ; i< 7; i++)
	{
		audioleftout2 = audioleftout2 + ((audioleftoutlow[13-i]+audioleftoutlow[i])* impulselow[i]);
	}
	audioout_binary = (alt_16)(audioleftout2/256);
	//checking the timing
	lrselect = IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE);
	while(lrselect)
	{
		lrselect = IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE);
	}
	//outputting filtered data
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_OUT_BASE, audioout_binary);
	//circular buffer, shifting data samples
	for (int k = 13; k > 0; k--)
	{
		audioleftoutlow[k]=audioleftoutlow[k-1];
	}
	audioleftout2 = 0;
}


//high pass sw3--------------------------------------------------------------------------------------------------------------------------------
else if(filterselect & 0b000010)
{
	audioleftin = IORD_ALTERA_AVALON_PIO_DATA(PIO_IN_BASE);
	audioleftouthigh[j] = (int)audioleftin;
	//filter implementation
	for (int i = 0 ; i< 6; i++)
	{
		audioleftout2 = audioleftout2 + ((audioleftouthigh[12-i]+audioleftouthigh[i])* impulsehigh[i]);
	}
	audioleftout2 = audioleftout2 + audioleftouthigh[6]*241;
	audioout_binary = (alt_16)(audioleftout2/256);
	//checking the timing
		lrselect = IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE);
		while(lrselect)
		{
			lrselect = IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE);
		}
	//outputting filtered data
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_OUT_BASE, audioout_binary);
	//circular buffer, shifting data samples
	for (int k = 12; k > 0; k--)
	{
		audioleftouthigh[k]=audioleftouthigh[k-1];
	}
	audioleftout2 = 0;
}


//flat sw4-------------------------------------------------------------------------------------------------------------------------------
else if((filterselect & 0b000100))
{
	audioleftin = IORD_ALTERA_AVALON_PIO_DATA(PIO_IN_BASE);
		audioleftoutflat[j] = (int)audioleftin;
		// filter implementation
		for (int i = 1 ; i< 7; i++)
		{
			audioleftout2 = audioleftout2 + ((audioleftoutflat[13-i]+audioleftoutflat[i])* impulseflat[i]);
		}
		audioout_binary = (alt_16)(audioleftout2/256);
		//checking the timing
			lrselect = IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE);
			while(lrselect)
			{
				lrselect = IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE);
			}
		//outputting filtered data
		IOWR_ALTERA_AVALON_PIO_DATA(PIO_OUT_BASE, audioout_binary);
		//circular buffer, shifting data samples
		for (int k = 13; k > 0; k--)
		{
			audioleftoutflat[k]=audioleftoutflat[k-1];
		}
		audioleftout2 = 0;
}

//pop sw5--------------------------------------------
else if((filterselect & 0b001000))
{
	audioleftin = IORD_ALTERA_AVALON_PIO_DATA(PIO_IN_BASE);
		audioleftoutpop[j] = (int)audioleftin;
		//filter implementation
		for (int i = 0 ; i< 10; i++)
		{
			audioleftout2 = audioleftout2 + ((audioleftoutpop[20-i]+audioleftoutpop[i])* impulsepop[i]);
		}
		audioleftout2 = audioleftout2 + audioleftoutpop[10]*32;
		audioout_binary = (alt_16)(audioleftout2/256);
		//checking the timing
			lrselect = IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE);
			while(lrselect)
			{
				lrselect = IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE);
			}
		//outputting filtered data
		IOWR_ALTERA_AVALON_PIO_DATA(PIO_OUT_BASE, audioout_binary);
		//circular buffer, shifting data samples
		for (int k = 20; k > 0; k--)
		{
			audioleftoutpop[k]=audioleftoutpop[k-1];
		}
		audioleftout2 = 0;
}
//Rock sw6--------------------------------------------
else if((filterselect & 0b010000))
{
	audioleftin = IORD_ALTERA_AVALON_PIO_DATA(PIO_IN_BASE);
			audioleftoutrock[j] = (int)audioleftin;
			//filter implementation
			for (int i = 0 ; i< 15; i++)
			{
				audioleftout2 = audioleftout2 + ((audioleftoutrock[30-i]+audioleftoutrock[i])* impulserock[i]);
			}
			audioleftout2 = audioleftout2 + audioleftoutrock[15]*251;
			audioout_binary = (alt_16)(audioleftout2/256);
			//checking the timing
				lrselect = IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE);
				while(lrselect)
				{
					lrselect = IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE);
				}
			//outputting filtered data
			IOWR_ALTERA_AVALON_PIO_DATA(PIO_OUT_BASE, audioout_binary);
			//circular buffer, shifting data samples
			for (int k = 30; k > 0; k--)
			{
				audioleftoutrock[k]=audioleftoutrock[k-1];
			}
			audioleftout2 = 0;
}
//voice sw7--------------------------------------------
else if((filterselect & 0b100000))
{
	audioleftin = IORD_ALTERA_AVALON_PIO_DATA(PIO_IN_BASE);
	debug = 0b00;
	IOWR_ALTERA_AVALON_PIO_DATA( PIO_2_BASE, debug);

	IOWR_ALTERA_AVALON_PIO_DATA(PIO_OUT_BASE, audioleftin);
		debug = 0b11;
	IOWR_ALTERA_AVALON_PIO_DATA( PIO_2_BASE, debug);
}
//pop sw5--------------------------------------------
else if((loopback & 0b1))
{
	audioleftin = IORD_ALTERA_AVALON_PIO_DATA(PIO_IN_BASE);
	debug = 0b00;
	IOWR_ALTERA_AVALON_PIO_DATA( PIO_2_BASE, debug);

	IOWR_ALTERA_AVALON_PIO_DATA(PIO_OUT_BASE, audioleftin);
		debug = 0b11;
	IOWR_ALTERA_AVALON_PIO_DATA( PIO_2_BASE, debug);
}

}
}






